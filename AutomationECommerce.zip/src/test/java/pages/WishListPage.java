package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.support.Color;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import stepDefinations.Hocks;

import java.time.Duration;

public class WishListPage {
    By Product1 = By.xpath("//div//button[@onclick='return AjaxCart.addproducttocart_catalog(\"/addproducttocart/catalog/18/2/1\"),!1']");
     By wishHeader = By.xpath("//div[@class='bar-notification success']");
    By SuccessMessage = By.xpath("//*[text()='The product has been added to your ']");
    By wishListBTN = By.xpath("//a[@href='/wishlist']");
    By Product2 = By.xpath("//div//button[@onclick='return AjaxCart.addproducttocart_catalog(\"/addproducttocart/catalog/43/2/1\"),!1']");
    By recipientName = By.id("giftcard_43_RecipientName");
    By recipientEmail = By.id("giftcard_43_RecipientEmail");
    By Name =By.id("giftcard_43_SenderName");
    By Email =By.id("giftcard_43_SenderEmail")     ;
    By addWishlist =By.xpath("//button[@id='add-to-wishlist-button-43']");
    By Quantity =By.xpath("//tbody//tr[1]//td[6]//input");

    public void clickOnWishList() {

        clickButton(Product1);
    }
    public String checkSucessMessageColour(){

        return getCssValue(wishHeader);
    }
    public boolean isDisplaysucessMessage(){

        return isDisplayMessage(SuccessMessage);
    }

    public String getCssValue(By element){
        String backGroundColour = Color.fromString(Hocks.driver.findElement(element).getCssValue("background-color")).asHex();
        return backGroundColour;
    }
    public void handleError(){
        WebDriverWait wait=new WebDriverWait(Hocks.driver, Duration.ofSeconds(10));
        wait.until(ExpectedConditions.invisibilityOf(Hocks.driver.findElement(wishHeader)));
    }
    public void navigateToWishListLink(){

        clickButton(wishListBTN);
    }

    public void clickOnAddWishList(){
        clickButton(Product2);
    }


    public void enterData(String receiptname,String receiptemail,String name, String email){
        sendText(recipientName,receiptname);
        sendText(recipientEmail,receiptemail);
        sendText(Name,name);
        sendText(Email,email);
    }
    public void clickonAddToWish(){

        clickButton(addWishlist);
    }
    public void getValueOfQuantity(){
        System.out.println(Hocks.driver.findElement(Quantity).getAttribute("value"));

    }

  public void sendText(By element,String value){
      Hocks.driver.findElement(element).sendKeys(value);
  }
    public boolean isDisplayMessage(By element){

        return Hocks.driver.findElement(element).isDisplayed();
    }

    public String getText(By element) {

        return Hocks.driver.findElement(element).getText();
    }
    public String getAttribute(By element) {

        return Hocks.driver.findElement(element).getAttribute("value");
    }

    public void clickButton(By element) {

        Hocks.driver.findElement(element).click();
    }
}



