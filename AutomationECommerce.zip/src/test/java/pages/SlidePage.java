package pages;

import org.openqa.selenium.By;
import stepDefinations.Hocks;

public class SlidePage {
    By slide1BTN =By.xpath("//div//a[@class='nivo-control active']");
    By slide2BTN =By.xpath("//div//a[@class='nivo-control']");
    By Slide1TXT =By.xpath("//div//a[@class='nivo-control active']");
    By Slide2TXT =By.xpath("//div//a[@class='nivo-control']");



    public void  openHomePage(){
        Hocks.driver.navigate().to("https://demo.nopcommerce.com/");
    }

    public void openSlide1(){
        clickButton(slide1BTN);
    }
    public void openSlide2(){
        clickButton(slide2BTN);
    }
    public void clickButton(By element){
        Hocks.driver.findElement(element).click();
    }
    public String getUrl(){
         return Hocks.driver.getCurrentUrl();
    }
}
