package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.support.Color;
import org.openqa.selenium.support.ui.Select;
import stepDefinations.Hocks;

public class RegisterPage {
    public Select select;
    By RegisterPageBTN = By.linkText("Register");
    By GenderRadioBTN = By.xpath("//input[@id='gender-female']");
    By firstNameTXTBOX = By.xpath("//input[@id='FirstName']");
    By lastNameTXTBOX = By.xpath("//input[@id='LastName']");
    By DayList = By.xpath("//select[@name='DateOfBirthDay']");
    By MonthList = By.xpath("//select[@name='DateOfBirthMonth']");
    By YearList = By.xpath("//select[@name='DateOfBirthYear']");
    By EmailTXTBOX = By.xpath("//input[@id='Email']");
    By companyNameTXTBOX = By.xpath("//input[@id='Company']");
    By PasswordTXTBOX = By.xpath("//input[@id='Password']");
    By confirmPasswordTXTBOX = By.xpath("//input[@id='ConfirmPassword']");
    By RegisterBTN = By.xpath("//button[@id='register-button']");
    public By successMessage = By.xpath("//div[text()='Your registration completed']");
    By ContinueBTN = By.xpath("//a[@class='button-1 register-continue-button']");
    By LogOutBTN = By.linkText("Log out");

    public void openRegistrationPage(){

        clickButton(RegisterPageBTN);
    }
    public void enterPersonalDetails(String firstname, String lastname, int day,
                                     int month, String year, String email, String company)
    {
        clickButton(GenderRadioBTN);
        sendText(firstNameTXTBOX,firstname);
        sendText(lastNameTXTBOX,lastname);
        selectByIndex(DayList,day);
        selectByIndex(MonthList,month);
        selectByVisibleText(YearList,year);
        sendText(EmailTXTBOX,email);
        sendText(companyNameTXTBOX,company);
    }
    public void enterPassword(String password)
    {
        sendText(PasswordTXTBOX,password);
        sendText(confirmPasswordTXTBOX,password);
    }
    public void clickOnRegisterButton() {
        clickButton(RegisterBTN);
    }
    public boolean issuccesfulMessageDisplay(){
        return isDisplay(successMessage);

    }
    public void continues(){

        clickButton(ContinueBTN);
    }

    public void sendText(By element,String Value){

        Hocks.driver.findElement(element).sendKeys(Value);
    }
    public boolean isDisplay(By element){
        return Hocks.driver.findElement(element).isDisplayed();

    }
    public void clickButton(By element){

        Hocks.driver.findElement(element).click();
    }

    public void selectByIndex(By element,int number){
        select=new Select(Hocks.driver.findElement(element));
        select.selectByIndex(number);
    }

    public void selectByVisibleText(By element,String text){
        select=new Select(Hocks.driver.findElement(element));
        select.selectByVisibleText(text);
    }

    public void selectByText(By element,String value){
        select=new Select(Hocks.driver.findElement(element));
        select.selectByValue(value);
    }
    public String GetCssColour(By element) {
       // String Colour = Hooks.driver.findElement(element).getCssValue("color");
        String hex = Color.fromString(Hocks.driver.findElement(element).getCssValue("color")).asHex();
        return hex;

    }
    public void userLoggedOut(){
        clickButton(LogOutBTN);
    }

 
}
