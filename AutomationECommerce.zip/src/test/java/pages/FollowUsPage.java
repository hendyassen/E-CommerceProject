package pages;

import org.openqa.selenium.By;
import stepDefinations.Hocks;

import java.util.ArrayList;

public class FollowUsPage {

    By facebookBTN = By.xpath("//a[@href='http://www.facebook.com/nopCommerce']");
    By TiwtterBTN = By.xpath("//a[@href='https://twitter.com/nopCommerce']");
    By RSSBTN = By.xpath("//a[@href='/news/rss/1']");
    By youTubeBTN = By.xpath("//a[@href='http://www.youtube.com/user/nopCommerce']");

    ArrayList<String> Tabs;

    public void scrolling(){
    }
    public void movesTofacebook() throws InterruptedException {
        clickButton(facebookBTN);
        Thread.sleep(1000);
        Tabs =new ArrayList<>(Hocks.driver.getWindowHandles());
        Hocks.driver.switchTo().window(Tabs.get(1));
        System.out.println( Hocks.driver.getCurrentUrl());
        System.out.println( Hocks.driver.getTitle());
    }
    public void closefacebook() throws InterruptedException {
        Thread.sleep(1000);
        Tabs =new ArrayList<>(Hocks.driver.getWindowHandles());
        Hocks.driver.close();
        Hocks.driver.switchTo().window(Tabs.get(0));
    }

    public void movesToTiwtter() throws InterruptedException {
        clickButton(TiwtterBTN);
        Thread.sleep(1000);
        Tabs =new ArrayList<>(Hocks.driver.getWindowHandles());
        Hocks.driver.switchTo().window(Tabs.get(1));
        System.out.println( Hocks.driver.getCurrentUrl());
        System.out.println( Hocks.driver.getTitle());
    }
    public void closeTiwtter() throws InterruptedException {
        Thread.sleep(1000);
        Tabs =new ArrayList<>(Hocks.driver.getWindowHandles());
        Hocks.driver.close();
        Hocks.driver.switchTo().window(Tabs.get(0));
    }

    public void movesToRSS() throws InterruptedException {
        clickButton(RSSBTN);
        Thread.sleep(1000);
        Tabs =new ArrayList<>(Hocks.driver.getWindowHandles());
        Hocks.driver.switchTo().window(Tabs.get(1));
        System.out.println( Hocks.driver.getCurrentUrl());
        System.out.println( Hocks.driver.getTitle());
    }
    public void closeRSS() throws InterruptedException {
        Thread.sleep(1000);
        Tabs =new ArrayList<>(Hocks.driver.getWindowHandles());
        Hocks.driver.close();
        Hocks.driver.switchTo().window(Tabs.get(0));
    }

    public void movesToyouTube() throws InterruptedException {
        clickButton(youTubeBTN);
        Thread.sleep(1000);
        Tabs =new ArrayList<>(Hocks.driver.getWindowHandles());
        Hocks.driver.switchTo().window(Tabs.get(1));
        System.out.println( Hocks.driver.getCurrentUrl());
        System.out.println( Hocks.driver.getTitle());
    }
    public void closeyouTube() throws InterruptedException {
        Thread.sleep(1000);
        Tabs =new ArrayList<>(Hocks.driver.getWindowHandles());
        Hocks.driver.close();
        Hocks.driver.switchTo().window(Tabs.get(0));
    }


    public void clickButton(By element) {
        Hocks.driver.findElement(element).click();
    }
    public void openHomePage(){
        Hocks.driver.navigate().to("https://demo.nopcommerce.com/");

    }
    public String getCurentURL(){
        return  Hocks.driver.getCurrentUrl();
    }

}
