package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.interactions.Actions;
import stepDefinations.Hocks;

public class HoverCategories {
    Actions actions;
    By CategoryBTN = By.xpath("//ul[@class='top-menu notmobile']//li//a[text()='Computers ']");
    By subCategoryBTN = By.xpath("(//a[@href='/desktops'])[1]");
    By PageTitle =By.xpath("//div[@class='page-title']//h1");


    public void hoverCategory() {
        Hocks.driver.navigate().to("https://demo.nopcommerce.com/");
        actions = new Actions(Hocks.driver);
        actions.moveToElement(Hocks.driver.findElement(CategoryBTN)).build().perform();
    }
    public void selectSubCategory(){
        actions.moveToElement(Hocks.driver.findElement(subCategoryBTN)).build().perform();
    }
    public void clickonSubCategory(){
        clickOnButton(subCategoryBTN);

    }
    public void clickOnButton(By element){
        Hocks.driver.findElement(element).click();
    }
    public String  getCurrentUrl(){
        return Hocks.driver.getCurrentUrl() ;
    }
    public String getTitleSubCategory(){
         String text= getText(PageTitle).toLowerCase().trim();
        System.out.println(text);
         return text;

    }
    public String getText(By element){

        return Hocks.driver.findElement(element).getText();
    }


}
