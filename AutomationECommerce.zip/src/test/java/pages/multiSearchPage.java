package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import stepDefinations.Hocks;

import java.util.List;

public class multiSearchPage {
    By productSearchBar = By.xpath("//input[@id='small-searchterms']");
    By SearchBTN = By.xpath("//button[@type='submit']");
    By SKUTXT = By.xpath("//span[@id='sku-4']");
    By Pic1 = By.xpath("//h2//a[@href='/science-faith']");
    By Pic2 = By.xpath("//h2//a[@href='/apple-icam']");
    By Pic3 = By.xpath("//h2//a[@href='/sound-forge-pro-11-recurring']");
    public int NoOfProduct = Hocks.driver.findElements(By.xpath("//h2[@class='product-title']")).size();

    public void openSearch(){
        Hocks.driver.navigate().to("https://demo.nopcommerce.com/");
        clickButton(productSearchBar);
    }

    public void searchProduct(String name){
        sendText(productSearchBar,name);
        clickButton(SearchBTN);
    }
    String product;
    public void VerifyingProduct(String name){
        List<WebElement> elements= Hocks.driver.findElements(By.xpath("//h2[@class='product-title']"));
        System.out.println("No. of elements:" +elements.size());
        for(int i=0; i<elements.size(); i++) {
            String product = elements.get(i).getText();
            System.out.println(product);
        }
    }

    public void moveToLink() {

        Hocks.driver.navigate().to("https://demo.nopcommerce.com/apple-macbook-pro-13-inch");
    }
    public String gettingText(){

        return getText(SKUTXT);
    }
    public boolean isDisplaySku(){

        return isDisplay(SKUTXT);
    }

    public String getCurrentUrl(){

        return Hocks.driver.getCurrentUrl();
    }

    public boolean Pic1IsAppeared(){

        return isDisplay(Pic1);
    }
    public boolean Pic2IsAppeared(){

        return isDisplay(Pic2);
    }
    public boolean Pic3IsAppeared(){

        return isDisplay(Pic3);
    }

    public void clickButton(By element){

        Hocks.driver.findElement(element).click();
    }

    public void sendText(By element,String value){

        Hocks.driver.findElement(element).sendKeys(value);
    }
    public String getText(By element){

        return Hocks.driver.findElement(element).getText();
    }
    public boolean isDisplay(By element){
        return Hocks.driver.findElement(element).isDisplayed() ;
    }
}
