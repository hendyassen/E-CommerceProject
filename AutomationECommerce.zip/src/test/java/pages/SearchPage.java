package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import stepDefinations.Hocks;

import java.util.List;

public class SearchPage {
    By SearchBar = By.xpath("//input[@id='small-searchterms']");
    By SearchBTN = By.xpath("//button[@type='submit']");
    By SKU = By.xpath("//div//span[@id='sku-4' and text()='AP_MBP_13']");
    By productBTN =By.xpath("//h2//a[@href='/apple-macbook-pro-13-inch']");


    public void openSearch(){

        clickButton(SearchBar);
    }
    public void searchProduct(String name){
        sendText(SearchBar,name);

    }
    public void clickSearch(){
        clickButton(SearchBTN);
    }
    String product;
    public String validateName(){
        List<WebElement> elements= Hocks.driver.findElements(By.xpath("//h2[@class='product-title']"));
        System.out.println("No. of elements:" +elements.size());
        for(int i=0; i<elements.size(); i++){
            String product=elements.get(i).getText();
            System.out.println(product);
        }
        return product;
    }

    public boolean verifyingSearch() {
        List<WebElement> elements = Hocks.driver.findElements(By.xpath("//h2[@class='product-title']"));
        System.out.println("No. of elements:" + elements.size());
        for (int i = 0; i < elements.size(); i++) {
            String product = elements.get(i).getText();
            if (product.contains("Apple")) {
                return true;
            }
        }
            return true;
        }




    public void moveToLink() {
        clickButton(productBTN);

    }
   public String getCurrentUrl(){

        return Hocks.driver.getCurrentUrl();
   }

public boolean checkSkuIsAppeared(){
        return isDisplay(SKU);
}
    public void clickButton(By element){

        Hocks.driver.findElement(element).click();
    }

    public void sendText(By element,String value){

        Hocks.driver.findElement(element).sendKeys(value);
    }
    public String getText(By element){

        return Hocks.driver.findElement(element).getText();
    }
    public boolean isDisplay(By element){
        return Hocks.driver.findElement(element).isDisplayed() ;
    }
}
