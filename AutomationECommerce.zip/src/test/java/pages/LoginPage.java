package pages;

import org.openqa.selenium.By;
import stepDefinations.Hocks;

public class LoginPage {
    By LoginPageBTN = By.linkText("Log in");
    By EmailTXTBOX = By.xpath("//input[@id='Email']");
    By PasswordTXTBOX = By.xpath("//input[@id='Password']");
    By LoginBTN = By.xpath("//button[@type='submit' and @class='button-1 login-button']");
    By MyAccountBTN = By.linkText("My account");

  public void openLoginPage(){
      Hocks.driver.navigate().to("https://demo.nopcommerce.com/");
      clickbtn(LoginPageBTN);
  }
  public void enterEmailAndPassword(String EmailText,String PasswordText){
      sendText(EmailTXTBOX,EmailText);
      sendText(PasswordTXTBOX,PasswordText);
  }
  public void clickonLoginButton(){

      clickbtn(LoginBTN);
  }

  public String getCurrentUrl(){

      return Hocks.driver.getCurrentUrl();
  }

  public boolean isDisplayLoggedAccount(){
      return isDisplay(MyAccountBTN);
  }
    public void clickbtn(By element){

        Hocks.driver.findElement(element).click();
    }
    public void sendText(By element,String Value){

        Hocks.driver.findElement(element).sendKeys(Value);
    }
    public boolean isDisplay(By element){
        return Hocks.driver.findElement(element).isDisplayed();

    }
}