package pages;

 import org.openqa.selenium.By;

 import org.openqa.selenium.JavascriptExecutor;
 import org.openqa.selenium.WebElement;
 import stepDefinations.Hocks;

 import java.util.List;

public class CurrencyPage {

     JavascriptExecutor js;
    By CurrencyList = By.xpath("//select//option[text()='Euro']");
    By FeaturedProducts = By.xpath("//div//*[text()='Featured products']");
    By ElementsPrice = By.xpath("//span[@class='price actual-price']");


   public void selectCurrency() {
      clickBTN(CurrencyList);
  }
  public void scrollDown(){
      scrollDownPage();
  }
  String EuroCurr;
     public String checkCurrency(){
         List<WebElement> elements= Hocks.driver.findElements(By.xpath("//span[@class='price actual-price']"));
         System.out.println("No. of elements:" +elements.size());
         for(int i=0; i<elements.size(); i++){
              EuroCurr =elements.get(i).getText();
             System.out.println(EuroCurr);
     }
         return EuroCurr;
     }


   public void scrollDownPage(){
        js = (JavascriptExecutor) Hocks.driver;
       js.executeScript("window.scrollBy(0,250)", "");

  }



    public void clickBTN(By element){

        Hocks.driver.findElement(element).click();
    }
    public void sendText(By element,String value){

        Hocks.driver.findElement(element).sendKeys(value);
    }

}
