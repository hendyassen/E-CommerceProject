package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import stepDefinations.Hocks;
import java.time.Duration;

public class CartPage {
    By addCartBTN = By.xpath("//button[@onclick='return AjaxCart.addproducttocart_catalog(\"/addproducttocart/catalog/18/1/1\"),!1']");
    By notifiedMSG = By.xpath("//*[text()='The product has been added to your ']");
    By notifiedBar = By.xpath("//div[@class='bar-notification success']");
    By Quantity =By.xpath("//tbody//tr[1]//td[5]//input");


  public void openPage(){
      Hocks.driver.navigate().to("https://demo.nopcommerce.com/");
  }
  public void addingtoCart(){
      clickBTN(addCartBTN);
  }
  public boolean isDisplayMSG(){
        return isDisplay(notifiedMSG);
  }
    public void errorException(){
        WebDriverWait wait=new WebDriverWait(Hocks.driver, Duration.ofSeconds(10));
        wait.until(ExpectedConditions.invisibilityOf(Hocks.driver.findElement(notifiedBar)));
    }

    public int getQuantity(){
        String value=getText(Quantity);
        System.out.println(value);
        int qValue=Integer.parseInt(value);
        System.out.println(qValue);
        return  qValue;

    }



    public void sendText(By element,String value) {
        Hocks.driver.findElement(element).sendKeys(value);
    }

    public String getText(By element) {
        return Hocks.driver.findElement(element).getText();
    }

    public void clickBTN(By element) {

        Hocks.driver.findElement(element).click();
    }
    public boolean isDisplay(By element){

        return Hocks.driver.findElement(element).isDisplayed() ;
    }
}
