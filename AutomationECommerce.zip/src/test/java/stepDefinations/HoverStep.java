package stepDefinations;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import org.testng.Assert;
import pages.HoverCategories;

public class HoverStep {
    HoverCategories hovercate =new HoverCategories();
    @Given("open nopcommerce Homepage and hover on a Category")
    public void HoverMouse(){
        hovercate.hoverCategory();

    }

    @Then("the user can open subCategory")
    public void openSubCategory(){
        hovercate.selectSubCategory();
        hovercate.clickonSubCategory();
        Assert.assertTrue(hovercate.getTitleSubCategory().contains("desktops"));
        Assert.assertTrue(hovercate.getCurrentUrl().contains("https://demo.nopcommerce.com/desktops"));
    }
}
