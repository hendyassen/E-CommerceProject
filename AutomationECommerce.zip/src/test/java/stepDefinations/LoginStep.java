package stepDefinations;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;


import org.testng.asserts.SoftAssert;
import pages.LoginPage;


public class LoginStep {
    LoginPage login= new LoginPage();
    SoftAssert softAssert;

    @Given("the user open Login page")
    public void navigatesToLoginPage(){
        login.openLoginPage();

    }
    @When("the user enter valid Email and Password")
    public void enterValidCredentials(){
      login.enterEmailAndPassword("Hendyassen30@gmail.com","12345678");
    }
    @And("the user click on Login Button")
    public void clickLoginButton(){
    login.clickonLoginButton();
    }
    @Then("the user should be logged in successfully")
    public void loginSuccessfully(){
        softAssert=new SoftAssert();
        softAssert.assertEquals(login.getCurrentUrl(),"https://demo.nopcommerce.com/");
        softAssert.assertTrue(login.isDisplayLoggedAccount());
        softAssert.assertAll();

    }
}
