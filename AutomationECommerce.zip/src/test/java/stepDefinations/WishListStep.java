package stepDefinations;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import org.testng.asserts.SoftAssert;
import pages.WishListPage;

public class WishListStep {
    WishListPage wishlist = new WishListPage();
    SoftAssert softassert;

    //Scenario1
    @Given("the user opens Nopcommerce page and clicks on heart icon")
    public void addingProductsToWishList() {
        wishlist.clickOnWishList();
    }

    @Then("a success message appeared")
    public void successMessageColour() {
        softassert = new SoftAssert();
        softassert.assertTrue(wishlist.isDisplaysucessMessage());
        softassert.assertEquals(wishlist.checkSucessMessageColour(), "#4bb07a");
        softassert.assertAll();
    }

    //Scenario2
    @Given("the user opens homepage and clicks on heart icon")
    public void clickOnWishList() {

        wishlist.clickOnWishList();
    }

    @Then("the element should be invisible")
    public void waitSuccessBar() {

        wishlist.handleError();
    }

    @Then("the user clicks on wishList page")
    public void openWishLink() {

        wishlist.navigateToWishListLink();
    }

    //Scenario3
    @Given("the user open homepage and add product to wishlist")
    public void addNewProduct() {
        wishlist.clickOnAddWishList();
    }


    @And("the user enter the required data")
    public void enterRequiredData() {
        wishlist.enterData("hend", "hendyassen@gmail.com", "hend5", "hendyassen3@gmail.com");
        wishlist.clickonAddToWish();
        wishlist.handleError();
    }


    @Then("the product added to wishlist successfully")
    public void validateResult() {
        wishlist.navigateToWishListLink();
        wishlist.getValueOfQuantity();

    }
}
