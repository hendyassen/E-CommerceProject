package stepDefinations;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.junit.Assert;
import org.testng.asserts.SoftAssert;
import pages.RegisterPage;


public class RegisterStep {
    RegisterPage register = new RegisterPage();
    SoftAssert softAssert;

    @Given("the user open Register page")
    public void navigatesToRegisterPage(){
        register.openRegistrationPage();
    }

    @When("the user enter required data")
    public void enterData(){
        register.enterPersonalDetails("Hend","Yassen",28,7,
                "1996","Hendyassen@gmail.com","TestPRO");

    }
    @And("the user enter password and confirmation password")
    public void enterValidPassword(){
    register.enterPassword("12345678");
    }

    @And("the user click on Register button")
    public void clickOnRegisteration(){
     register.clickOnRegisterButton();
    }
    @Then("the user registered successfully")
    public void registerSuccessfully(){
        softAssert=new SoftAssert();
        softAssert.assertTrue(register.issuccesfulMessageDisplay());
        softAssert.assertAll();
		//Assert.assertEquals("rgba(76, 177, 124, 1)",reg.GetCssColour(reg.txt_sucessMessage));
       Assert.assertEquals(register.GetCssColour(register.successMessage),"#4cb17c");
        
    }
    @And("the user log out")
    public void logOut(){
        register.userLoggedOut();
 }

}
