package stepDefinations;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.junit.Assert;
import pages.CurrencyPage;

public class CurrencyStep {
    CurrencyPage currency=new CurrencyPage();

    @Given("the user click on dropdown list of currency and click on Euro")
    public void ClickonEuroCurrency(){
        currency.selectCurrency();
    }
    @When("the user scroll down")
    public void scrolldownPage(){
        currency.scrollDown();
    }
    @Then("Euro is displayed")
    public void selectEuro(){
        Assert.assertTrue(currency.checkCurrency().contains("€"));

    }
}
