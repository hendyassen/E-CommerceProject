package stepDefinations;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import org.junit.Assert;
import pages.CartPage;

public class AddToCartStep {
    CartPage cart=new CartPage();

 //Scenario1
    @Given("user open nopcommerce page and click on add Cart")
    public void openPage(){
       cart.openPage();
        cart.addingtoCart();


    }

    @Then("Shopping notification is appeared")
    public void verifiedMessage(){
       Assert.assertTrue(cart.isDisplayMSG());

    }
}
