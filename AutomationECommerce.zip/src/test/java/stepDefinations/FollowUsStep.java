package stepDefinations;

import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.testng.Assert;
import pages.FollowUsPage;

public class FollowUsStep {
    FollowUsPage followus =new FollowUsPage();

    @When("user click on facebook")
    public void NavigatesToFaceBook() throws InterruptedException {
        followus.movesTofacebook();
        Assert.assertEquals(followus.getCurentURL(),"https://www.facebook.com/nopCommerce");
    }
    @Then("user close facebook and back to home page")
    public void closeFacebookTab() throws InterruptedException {
        followus.closefacebook();
    }
      
       
   // user able to open twitter
    @When("the user open twitter")
    public void navigatesToTwitter() throws InterruptedException {
        followus.movesToTiwtter();
        Assert.assertEquals(followus.getCurentURL(),"https://twitter.com/nopCommerce");

    }
    @Then("the user close twitter and back to home page")

    public void closetwitterTab() throws InterruptedException {
        followus.closeTiwtter();
    }
    //user able to open Rss
    @When("the user open Rss")
    public void navigatesToRSS() throws InterruptedException {
        followus.movesToRSS();
        Assert.assertEquals(followus.getCurentURL(),"https://demo.nopcommerce.com/news/rss/1");
    }
    @Then("the user close Rss and back to home page")
    public void closeRSSTab() throws InterruptedException {
        followus.closeRSS();
    }
     
   // user able to open youTube
    @When("the user open youTube")
    public void navigatesToYouTube() throws InterruptedException {
        followus.movesToyouTube();
        Assert.assertEquals(followus.getCurentURL(),"https://www.youtube.com/user/nopCommerce");
    }
    @Then("the user close youTube and back to home page")
    public void closeYouTubeTab() throws InterruptedException {
        followus.closeyouTube();
    }
}
