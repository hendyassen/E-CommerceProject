package stepDefinations;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.junit.Assert;
import pages.SearchPage;

public class SearchStep {

SearchPage home=new SearchPage();

    @Given("the user open Home Page and click on search bar")
    public void NavigatesToSearchBar(){
        home.openSearch();

    }
    @When("^the user enter Product as \"(.*)\"$")
    public void searchProduct(String product){

        home.searchProduct(product);
    }
    @And("the user click on search button")
    public void clickToSearchProduct(){

        home.clickSearch();
    }
    @Then("the search result contains Apple word")
    public void searchResult(){
       // Assert.assertTrue(home.verifyName().contains("Apple"));
        Assert.assertTrue(home.verifyingSearch());

    }
    @And("the user open product link and the Sku appears")
    public void skuLink(){
        home.moveToLink();
        Assert.assertTrue(home.checkSkuIsAppeared());
    }

}
