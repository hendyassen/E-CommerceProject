package stepDefinations;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import org.testng.Assert;
import org.testng.asserts.SoftAssert;
import pages.SlidePage;

public class SliderStep {
    SlidePage slider = new SlidePage();
    SoftAssert softAssert;



    @Given("the user can click on slide1")
    public void openSlide1() {
        slider.openHomePage();

    }
    @Then("the user compares between URls of first slide and then it fails")
    public void comparesSlide1() {
        slider.openSlide1();
        Assert.assertEquals(slider.getUrl(), "https://demo.nopcommerce.com/nokia-lumia-1020");
    }

    @Given("user can click on slide2")
    public void openSlide2() {
        slider.openHomePage();
    }
    @Then("the user compares between URls of second slide and then it fails")
    public void comparesSlide2() {
        slider.openSlide2();
        Assert.assertEquals(slider.getUrl(), "https://demo.nopcommerce.com/iphone");
    }

}